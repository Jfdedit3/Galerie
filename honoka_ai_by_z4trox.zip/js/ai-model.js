export class AIModel {
  constructor() {
    this.models = {
      'gpt-3.5': {
        name: 'Honoka GPT-4',
        version: '4.0',
        description: 'Most powerful model, best for complex tasks',
        contextLength: '8k tokens',
        status: 'active'
      },
      'claude': {
        name: 'Honoka Claude',
        version: '2.0',
        description: 'Specialized in analysis and coding',
        contextLength: '10k tokens',
        status: 'active'
      }
    };
    
    this.currentModel = 'gpt-3.5';
  }

  setModel(modelId) {
    if (this.models[modelId]) {
      this.currentModel = modelId;
      return true;
    }
    return false;
  }

  getCurrentModel() {
    return this.models[this.currentModel];
  }

  getAllModels() {
    return this.models;
  }

  async getResponse(message) {
    try {
      const model = this.getCurrentModel();
      const response = await fetch('/api/ai_completion', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({
          prompt: `You are Honoka, an advanced AI assistant using the ${model.name} model. You have a warm, friendly, and helpful personality with a slight kawaii touch. You're direct but kind, and you always aim to provide detailed, accurate information. When providing code examples, always wrap them in triple backticks with the appropriate language specification (e.g. \`\`\`javascript).
        
          Respond to the following message in a natural, engaging way while maintaining your distinct personality:
          
          interface Response {
            reply: string;
          }
          
          {
            "reply": "Here's what I know about that..."
          }`,
          data: message,
          model: this.currentModel
        }),
      });
      
      if (!response.ok) {
        throw new Error(`API responded with status: ${response.status}`);
      }
      
      const data = await response.json();
      return data.reply;
    } catch (error) {
      if (window.debugMenu) {
        window.debugMenu.logError({
          type: 'API Error',
          message: error.message,
          stack: error.stack
        });
      }
      console.error('Error in AI model:', error);
      throw error;
    }
  }
}