import { ChatUI } from './chat-ui.js';
import { AIModel } from './ai-model.js';
import { DebugMenu } from './debug-menu.js';
import { setupMobileNavigation } from './mobile-nav.js';

class App {
  constructor() {
    this.chatUI = new ChatUI();
    this.aiModel = new AIModel();
    this.debugMenu = new DebugMenu(this.aiModel);
    // Make debug menu globally accessible for error logging
    window.debugMenu = this.debugMenu;
    this.init();
    this.setupModelSelector();
    this.showInitialWarning();
    this.setupNekoImageCommands();
    
    // Initialize mobile navigation
    setupMobileNavigation();
  }

  init() {
    this.chatUI.onSendMessage(async (message) => {
      // Check for neko image commands
      const nekoCategories = ['neko', 'waifu', 'kitsune', 'husbando'];
      const matchedCategory = nekoCategories.find(category => 
        message.toLowerCase().includes(`show me a ${category}`) || 
        message.toLowerCase().includes(`get ${category}`)
      );

      if (matchedCategory) {
        this.chatUI.showLoading();
        await this.chatUI.handleNekoImageRequest(matchedCategory);
        this.chatUI.hideLoading();
        return;
      }

      // Existing AI response logic
      this.chatUI.addMessage(message, 'user');
      this.chatUI.showLoading();
      
      try {
        // Get AI response
        const response = await this.aiModel.getResponse(message);
        
        // Hide loading and add AI response
        this.chatUI.hideLoading();
        this.chatUI.addMessage(response, 'ai');
      } catch (error) {
        console.error('Error getting AI response:', error);
        this.chatUI.hideLoading();
        this.chatUI.addMessage('Sorry, I encountered an error. Please try again.', 'ai');
      }
    });
  }

  setupNekoImageCommands() {
    // Optional: Add any additional setup for neko image interactions
  }

  showInitialWarning() {
    // Show a one-time warning toast when the app loads
    const toast = document.createElement('div');
    toast.className = 'warning-toast';
    toast.innerHTML = `
      <div class="warning-toast-content">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
          <line x1="12" y1="9" x2="12" y2="13"/>
          <line x1="12" y1="17" x2="12" y2="17"/>
        </svg>
        <div class="warning-message">
          <strong>Default Model Active</strong>
          <p>You're currently using the basic model with limited capabilities. Switch to GPT-4 for enhanced performance.</p>
        </div>
        <button class="close-warning">×</button>
      </div>
    `;
    document.body.appendChild(toast);

    // Remove the toast after 10 seconds or when clicked
    const closeBtn = toast.querySelector('.close-warning');
    const removeToast = () => {
      toast.classList.add('fade-out');
      setTimeout(() => toast.remove(), 300);
    };
    closeBtn.addEventListener('click', removeToast);
    setTimeout(removeToast, 10000);
  }

  setupModelSelector() {
    const modelOptions = document.querySelectorAll('.model-option');
    const modelName = document.querySelector('.model-name');
  
    // Store current selection
    let currentModelId = 'gpt-3.5'; 

    const updateSelection = (modelId) => {
      if (this.aiModel.setModel(modelId)) {
        // Update stored selection
        currentModelId = modelId;
        
        // Update UI elements
        modelOptions.forEach(opt => {
          opt.classList.remove('selected');
          if (opt.dataset.model === modelId) {
            opt.classList.add('selected');
          }
        });

        const currentModel = this.aiModel.getCurrentModel();
        modelName.textContent = currentModel.name;
        
        // Update debug menu if available
        if (this.debugMenu) {
          const modelInfo = document.querySelector('#model-info');
          if (modelInfo) {
            modelInfo.innerHTML = this.debugMenu.getModelInfoHTML();
          }
        }

        // Store selection in localStorage for persistence
        localStorage.setItem('selectedModel', modelId);
      }
    };

    // Add click handlers
    modelOptions.forEach(option => {
      option.addEventListener('click', (e) => {
        e.preventDefault();
        const modelId = option.dataset.model;
        updateSelection(modelId);
      });
    });

    // Restore previous selection on page load
    const savedModel = localStorage.getItem('selectedModel');
    if (savedModel) {
      updateSelection(savedModel);
    } else {
      updateSelection(currentModelId);
    }
  }
}

// Initialize the app
new App();