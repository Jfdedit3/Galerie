export class ChatUI {
  constructor() {
    this.messagesContainer = document.getElementById('messages');
    this.form = document.getElementById('chat-form');
    this.input = document.getElementById('user-input');
    
    this.setupEventListeners();
    this.autoResizeInput();
    this.setupTypingEffect();
    this.setupMessageAnimation();
    this.setupScrollToBottom();
    this.setupMobileScrollBehavior();
    
    // Add preloader messages as popups on initialization
    this.showPreloaderPopups();
    
    this.setupNekoImageIntegration();
  }

  showPreloaderPopups() {
    const preloaderMessages = [
      "Initializing Honoka AI...",
      "Loading advanced language models...",
      "Preparing conversational context...",
      "Warming up neural networks...",
      "Setting up personalized interaction space..."
    ];

    // Create a popup container if it doesn't exist
    if (!document.querySelector('.preloader-popup-container')) {
      const popupContainer = document.createElement('div');
      popupContainer.className = 'preloader-popup-container';
      document.body.appendChild(popupContainer);
    }

    const popupContainer = document.querySelector('.preloader-popup-container');

    preloaderMessages.forEach((message, index) => {
      setTimeout(() => {
        this.createPreloaderPopup(message, popupContainer);
        
        // If it's the last preloader message, add a completion message
        if (index === preloaderMessages.length - 1) {
          setTimeout(() => {
            this.createPreloaderPopup("Ready to assist you! What would you like to explore today?", popupContainer);
          }, 1000);
        }
      }, index * 1500);
    });
  }

  createPreloaderPopup(message, container) {
    const popup = document.createElement('div');
    popup.className = 'preloader-popup';
    
    const popupContent = document.createElement('div');
    popupContent.className = 'preloader-popup-content';
    
    const icon = document.createElement('div');
    icon.className = 'preloader-popup-icon';
    icon.innerHTML = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        <path d="M12 15l4-4M12 15l-4-4"/>
      </svg>
    `;

    const text = document.createElement('div');
    text.className = 'preloader-popup-text';
    text.textContent = message;

    const closeButton = document.createElement('button');
    closeButton.className = 'preloader-popup-close';
    closeButton.innerHTML = '×';
    closeButton.setAttribute('aria-label', 'Close popup');

    popupContent.appendChild(icon);
    popupContent.appendChild(text);
    popupContent.appendChild(closeButton);
    popup.appendChild(popupContent);
    container.appendChild(popup);

    // Trigger reflow to enable animation
    popup.offsetWidth;
    popup.classList.add('visible');

    // Close popup on button click
    closeButton.addEventListener('click', () => {
      popup.classList.remove('visible');
      setTimeout(() => {
        popup.remove();
      }, 500);
    });

    // Automatically remove popup after 5 seconds if not manually closed
    const autoCloseTimer = setTimeout(() => {
      if (popup.classList.contains('visible')) {
        popup.classList.remove('visible');
        setTimeout(() => {
          popup.remove();
        }, 500);
      }
    }, 5000);

    // Clear timer if popup is manually closed earlier
    closeButton.addEventListener('click', () => {
      clearTimeout(autoCloseTimer);
    });
  }

  setupEventListeners() {
    // Handle form submit
    this.form.addEventListener('submit', (e) => {
      e.preventDefault();
      this.sendMessage();
    });

    // Handle Enter key press
    this.input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.sendMessage();
      }
    });
  }

  sendMessage() {
    const message = this.input.value.trim();
    if (message) {
      this.callback?.(message);
      this.input.value = '';
      this.input.style.height = 'auto';
    }
  }

  autoResizeInput() {
    this.input.addEventListener('input', () => {
      this.input.style.height = 'auto';
      this.input.style.height = this.input.scrollHeight + 'px';
    });
  }

  onSendMessage(callback) {
    this.callback = callback;
  }

  formatTimestamp() {
    return new Intl.DateTimeFormat('en-US', {
      hour: 'numeric',
      minute: 'numeric',
      hour12: true
    }).format(new Date());
  }

  setupTypingEffect() {
    const originalAddMessage = this.addMessage.bind(this);
    this.addMessage = (content, type) => {
      if (type === 'ai') {
        const contentDiv = document.createElement('div');
        contentDiv.className = 'content typing-container';
        
        originalAddMessage(content, type);
        
        const messageDiv = this.messagesContainer.lastElementChild;
        const contentContainer = messageDiv.querySelector('.content');
        
        let index = 0;
        const typeText = () => {
          if (index <= content.length) {
            // Ensure the full content is rendered
            contentContainer.textContent = content.slice(0, index + 1);
            index++;
            
            // Slightly randomize typing speed to make it more natural
            const typingSpeed = Math.random() * 30 + 20; // between 20-50ms
            
            // Continue typing
            setTimeout(typeText, typingSpeed);
          } else {
            // Remove typing container class when fully typed
            contentContainer.classList.remove('typing-container');
          }
        };
        
        // Start typing with a slight initial delay
        setTimeout(typeText, 500);
      } else {
        originalAddMessage(content, type);
      }
    };
  }

  setupMessageAnimation() {
    // Enhance the original addMessage method with animation
    const originalAddMessage = this.addMessage.bind(this);
    this.addMessage = (content, type) => {
      const messageDiv = document.createElement('div');
      messageDiv.className = `message ${type}-message message-animate`;
      
      const avatar = document.createElement('div');
      avatar.className = 'avatar';
      if (type === 'ai') {
        avatar.innerHTML = `<img src="https://files.catbox.moe/evfh55.jpg" alt="Honoka AI" class="avatar-img">`;
      } else {
        avatar.innerHTML = `
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="8" r="5"/>
            <path d="M20 21a8 8 0 10-16 0"/>
          </svg>
        `;
      }

      const messageContent = document.createElement('div');
      messageContent.className = 'message-content';

      const header = document.createElement('div');
      header.className = 'message-header';
      
      const name = document.createElement('span');
      name.className = type === 'ai' ? 'ai-name' : 'user-name';
      name.textContent = type === 'ai' ? 'Honoka' : 'You';
      
      const timestamp = document.createElement('span');
      timestamp.className = 'timestamp';
      timestamp.textContent = this.formatTimestamp();

      header.appendChild(name);
      header.appendChild(timestamp);

      const contentDiv = document.createElement('div');
      contentDiv.className = 'content';
      
      // Process content for code blocks
      if (type === 'ai') {
        contentDiv.innerHTML = this.processCodeBlocks(content);
        // Initialize syntax highlighting
        if (window.Prism) {
          Prism.highlightAllUnder(contentDiv);
        }
        // Add copy functionality to code blocks
        this.setupCopyButtons(contentDiv);
      } else {
        contentDiv.textContent = content;
      }

      messageContent.appendChild(header);
      messageContent.appendChild(contentDiv);

      messageDiv.appendChild(avatar);
      messageDiv.appendChild(messageContent);

      // Add animation classes
      messageDiv.classList.add('message-slide-in');
      
      // Append message with a slight delay for staggered animation
      setTimeout(() => {
        this.messagesContainer.appendChild(messageDiv);
        
        // Remove animation class after animation completes
        setTimeout(() => {
          messageDiv.classList.remove('message-slide-in');
        }, 500);
      }, type === 'ai' ? 500 : 0);
    };
  }

  setupScrollToBottom() {
    // Ensure messages container always scrolls to bottom
    const scrollToBottom = () => {
      if (this.messagesContainer) {
        // Use smooth scroll for better mobile experience
        this.messagesContainer.scrollTo({
          top: this.messagesContainer.scrollHeight,
          behavior: 'smooth'
        });
      }
    };

    // Call on each new message
    const originalAddMessage = this.addMessage.bind(this);
    this.addMessage = (content, type) => {
      originalAddMessage(content, type);
      
      // Use requestAnimationFrame for smoother scrolling
      requestAnimationFrame(() => {
        scrollToBottom();
      });
    };

    // Call when loading initial messages or after window resize
    window.addEventListener('resize', scrollToBottom);
  }

  setupMobileScrollBehavior() {
    if (this.messagesContainer) {
      this.messagesContainer.addEventListener('touchstart', (e) => {
        const scrollTop = this.messagesContainer.scrollTop;
        const scrollHeight = this.messagesContainer.scrollHeight;
        const clientHeight = this.messagesContainer.clientHeight;
        
        if (scrollTop === 0) {
          this.messagesContainer.scrollTop = 1;
        } else if (scrollTop + clientHeight >= scrollHeight - 1) {
          this.messagesContainer.scrollTop = scrollHeight - clientHeight - 1;
        }
      }, { passive: true });
    }
  }

  forceScrollToBottom() {
    if (this.messagesContainer) {
      // Use smooth scroll for better mobile experience
      this.messagesContainer.scrollTo({
        top: this.messagesContainer.scrollHeight,
        behavior: 'smooth'
      });
    }
  }

  async setupNekoImageIntegration() {
    this.nekoCache = new Map(); 
    this.fetchNekoImage = async (category = 'neko', options = {}) => {
      const { 
        type = 'img', 
        cacheTimeout = 600000 
      } = options;

      const cacheKey = `${category}_${type}`;
      const cachedResult = this.nekoCache.get(cacheKey);
      
      if (cachedResult && (Date.now() - cachedResult.timestamp) < cacheTimeout) {
        return cachedResult.data;
      }

      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 3000); 

        const response = await fetch(`https://nekos.best/api/v2/${category}`, {
          method: 'GET',
          signal: controller.signal,
          headers: {
            'Accept': 'application/json',
            'Cache-Control': 'no-cache'
          }
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();
        
        const imageResult = {
          url: data.results[0]?.url || null,
          artist: data.results[0]?.artist_name || 'Unknown',
          source: data.results[0]?.source_url || null,
          type: type,
          timestamp: Date.now()
        };

        this.nekoCache.set(cacheKey, {
          data: imageResult,
          timestamp: Date.now()
        });

        return imageResult;
      } catch (error) {
        console.error(`Neko Image Fetch Error (${category}):`, error);
        
        const fallbackImages = {
          'neko': 'https://nekos.best/placeholder/neko.jpg',
          'waifu': 'https://nekos.best/placeholder/waifu.jpg',
          'kitsune': 'https://nekos.best/placeholder/kitsune.jpg'
        };

        return {
          url: fallbackImages[category] || fallbackImages['neko'],
          artist: 'Fallback Image',
          source: 'https://nekos.best',
          error: true
        };
      }
    };

    this.nekoCommands = {
      '/neko': 'neko',
      '/waifu': 'waifu',
      '/kitsune': 'kitsune',
      '/husbando': 'husbando',
      '/neko gif': 'neko_gif',
      '/waifu gif': 'waifu_gif'
    };
  }

  async handleNekoImageRequest(trigger) {
    const startTime = performance.now();
    
    try {
      const category = this.nekoCommands[trigger] || trigger;
      
      this.showLoading();
      const imageData = await this.fetchNekoImage(category);
      
      if (imageData && imageData.url) {
        const processingTime = Math.round(performance.now() - startTime);
        
        const messageContext = imageData.error 
          ? `Encountered an issue fetching the ${category} image. Using a fallback.` 
          : `Here's a cute ${category} image just for you! `;
        
        const messageOptions = {
          imageUrl: imageData.url,
          artist: imageData.artist,
          source: imageData.source,
          processingTime: processingTime
        };

        if (window.debugMenu && !imageData.error) {
          window.debugMenu.logPerformanceMetric({
            type: 'Image Fetch',
            category: category,
            time: processingTime
          });
        }

        this.addMessage(messageContext, 'ai', messageOptions);
      } else {
        this.addMessage(`Sorry, I couldn't retrieve a ${category} image right now.`, 'ai');
      }
    } catch (error) {
      console.error('Comprehensive Neko Image Error:', error);
      this.addMessage('Oops! An unexpected error occurred while fetching the image.', 'ai');
    } finally {
      this.hideLoading();
    }
  }

  async handleCodeError(errorMessage, originalCode) {
    try {
      const response = await fetch('/api/ai_completion', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({
          prompt: `You are a code debugging assistant. A user encountered the following error:

${errorMessage}

Here's the original code:
\`\`\`
${originalCode}
\`\`\`

Please:
1. Analyze the error
2. Provide a corrected version of the code
3. Explain the specific issues and how they were fixed
4. Wrap the corrected code in triple backticks with the appropriate language

Respond in this format:
\`\`\`typescript
interface Response {
  correctedCode: string;
  explanation: string;
}
\`\`\`

Example:
{
  "correctedCode": "// Corrected code here",
  "explanation": "Specific details about the error and fix"
}`,
          data: {
            error: errorMessage,
            code: originalCode
          }
        }),
      });
      
      if (!response.ok) {
        throw new Error(`API responded with status: ${response.status}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error in code correction:', error);
      return {
        correctedCode: originalCode,
        explanation: 'Unable to automatically correct the code. Please review the error manually.'
      };
    }
  }

  addMessage(content, type, options = {}) {
    const { imageUrl, artist, source, processingTime } = options;
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}-message`;
    
    const avatar = document.createElement('div');
    avatar.className = 'avatar';
    if (type === 'ai') {
      avatar.innerHTML = `<img src="https://files.catbox.moe/evfh55.jpg" alt="Honoka AI" class="avatar-img">`;
    } else {
      avatar.innerHTML = `
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="8" r="5"/>
          <path d="M20 21a8 8 0 10-16 0"/>
        </svg>
      `;
    }

    const messageContent = document.createElement('div');
    messageContent.className = 'message-content';

    const header = document.createElement('div');
    header.className = 'message-header';
    
    const name = document.createElement('span');
    name.className = type === 'ai' ? 'ai-name' : 'user-name';
    name.textContent = type === 'ai' ? 'Honoka' : 'You';
    
    const timestamp = document.createElement('span');
    timestamp.className = 'timestamp';
    timestamp.textContent = this.formatTimestamp();

    header.appendChild(name);
    header.appendChild(timestamp);

    const contentDiv = document.createElement('div');
    contentDiv.className = 'content';
    
    if (type === 'ai') {
      contentDiv.innerHTML = this.processCodeBlocks(content);
      if (window.Prism) {
        Prism.highlightAllUnder(contentDiv);
      }
      this.setupCopyButtons(contentDiv);
    } else {
      contentDiv.textContent = content;
    }

    messageContent.appendChild(header);
    messageContent.appendChild(contentDiv);

    if (imageUrl) {
      const imageContainer = document.createElement('div');
      imageContainer.className = 'message-image-container';
      
      const image = document.createElement('img');
      image.src = imageUrl;
      image.alt = `${type === 'ai' ? 'Neko' : 'User'} Image`;
      image.className = 'message-attachment-image';
      
      image.addEventListener('load', () => {
        image.classList.add('image-loaded');
      });
      
      image.addEventListener('error', () => {
        image.classList.add('image-error');
        image.alt = 'Image failed to load';
      });
      
      if (artist || source) {
        const imageMetadata = document.createElement('div');
        imageMetadata.className = 'image-metadata';
        
        if (artist) {
          const artistSpan = document.createElement('span');
          artistSpan.textContent = `Artist: ${artist}`;
          imageMetadata.appendChild(artistSpan);
        }
        
        if (source) {
          const sourceLink = document.createElement('a');
          sourceLink.href = source;
          sourceLink.textContent = 'Source';
          sourceLink.target = '_blank';
          sourceLink.rel = 'noopener noreferrer';
          imageMetadata.appendChild(sourceLink);
        }
        
        imageContainer.appendChild(imageMetadata);
      }
      
      imageContainer.appendChild(image);
      messageContent.appendChild(imageContainer);
    }

    messageDiv.appendChild(avatar);
    messageContent.appendChild(contentDiv);
    messageDiv.appendChild(messageContent);
    this.messagesContainer.appendChild(messageDiv);
    
    this.forceScrollToBottom();

    if (type === 'ai' && content.includes('Error:')) {
      const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/;
      const match = content.match(codeBlockRegex);
      
      if (match) {
        const language = match[1] || 'plaintext';
        const originalCode = match[2].trim();
        
        // Extract error message
        const errorLines = content.split('\n').filter(line => line.includes('Error:'));
        const errorMessage = errorLines.length > 0 ? errorLines[0] : 'Unknown error occurred';
        
        // Attempt to get corrected code
        this.handleCodeError(errorMessage, originalCode)
          .then(correction => {
            // Replace the original message with corrected code
            const correctedMessage = `
              ${content}

              ### Code Correction Suggestion:
              
              ${correction.explanation}

              Corrected Code:
              \`\`\`${language}
              ${correction.correctedCode}
              \`\`\`
            `;
            
            // Update the last message's content
            const lastMessage = this.messagesContainer.lastElementChild;
            if (lastMessage) {
              const contentDiv = lastMessage.querySelector('.content');
              if (contentDiv) {
                contentDiv.innerHTML = this.processCodeBlocks(correctedMessage);
                
                // Re-apply syntax highlighting and copy buttons
                if (window.Prism) {
                  window.Prism.highlightAllUnder(contentDiv);
                }
                this.setupCopyButtons(contentDiv);
              }
            }
          })
          .catch(error => {
            console.error('Code correction failed:', error);
          });
      }
    }
  }

  processHTMLPreview(code) {
    try {
      // Create a container for the preview
      const previewContainer = document.createElement('div');
      previewContainer.className = 'html-preview-container';

      // Create an iframe to safely render the HTML
      const iframe = document.createElement('iframe');
      iframe.className = 'html-preview-iframe';
      iframe.sandbox = 'allow-scripts allow-same-origin';
      
      // Wrap the code in a complete HTML document
      const fullHTML = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { 
              font-family: Arial, sans-serif; 
              margin: 0; 
              padding: 10px; 
              background: #f4f4f4; 
              display: flex;
              justify-content: center;
              align-items: center;
              min-height: 100vh;
            }
            .preview-container {
              background: white;
              border-radius: 8px;
              box-shadow: 0 4px 6px rgba(0,0,0,0.1);
              padding: 20px;
              max-width: 100%;
              overflow: auto;
            }
          </style>
        </head>
        <body>
          <div class="preview-container">
            ${code}
          </div>
        </body>
        </html>
      `;

      // Set iframe content
      iframe.srcdoc = fullHTML;

      // Create a resize handler to adjust iframe height
      const resizeObserver = new ResizeObserver(entries => {
        for (let entry of entries) {
          iframe.style.height = `${entry.contentRect.height + 40}px`;
        }
      });

      iframe.onload = () => {
        const previewBody = iframe.contentDocument.body;
        resizeObserver.observe(previewBody);
      };

      // Add interaction buttons
      const buttonContainer = document.createElement('div');
      buttonContainer.className = 'html-preview-actions';
      
      const runButton = document.createElement('button');
      runButton.textContent = 'Run Code';
      runButton.className = 'run-preview-btn';
      runButton.onclick = () => {
        // Trigger full screen preview
        const fullScreenPreview = document.createElement('div');
        fullScreenPreview.className = 'fullscreen-html-preview';
        fullScreenPreview.innerHTML = `
          <div class="preview-modal">
            <button class="close-preview">×</button>
            <iframe 
              class="fullscreen-iframe" 
              srcdoc="${this.escapeHtml(fullHTML)}" 
              sandbox="allow-scripts allow-same-origin"
            ></iframe>
          </div>
        `;
        
        document.body.appendChild(fullScreenPreview);
        
        // Close button functionality
        fullScreenPreview.querySelector('.close-preview').onclick = () => {
          fullScreenPreview.remove();
        };
      };

      buttonContainer.appendChild(runButton);

      previewContainer.appendChild(buttonContainer);
      previewContainer.appendChild(iframe);

      return previewContainer;
    } catch (error) {
      console.error('HTML Preview Error:', error);
      return null;
    }
  }

  processCodeBlocks(content) {
    const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g;
    
    return content.replace(codeBlockRegex, (match, language, code) => {
      language = language || 'plaintext';
      
      // Add HTML preview for HTML code blocks
      const htmlPreview = language === 'html' 
        ? this.processHTMLPreview(code.trim()) 
        : '';
      
      return `
        <div class="code-block">
          <div class="code-header">
            <span class="language-label">${language}</span>
            <button class="copy-button" data-code="${encodeURIComponent(code.trim())}">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M8 4v12a2 2 0 002 2h8a2 2 0 002-2V7.242a2 2 0 00-.602-1.43L16.083 2.57A2 2 0 0014.685 2H10a2 2 0 00-2 2z"/>
                <path d="M16 18v2a2 2 0 01-2 2H6a2 2 0 01-2-2V9a2 2 0 012-2h2"/>
              </svg>
              Copy
            </button>
          </div>
          <pre><code class="language-${language}">${this.escapeHtml(code.trim())}</code></pre>
          ${htmlPreview ? `<div class="html-preview">${htmlPreview.outerHTML}</div>` : ''}
        </div>
      `;
    });
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  setupCopyButtons(container) {
    container.querySelectorAll('.copy-button').forEach(button => {
      button.addEventListener('click', async () => {
        const code = decodeURIComponent(button.dataset.code);
        await navigator.clipboard.writeText(code);
        
        const originalContent = button.innerHTML;
        button.innerHTML = `
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 6L9 17l-5-5"/>
          </svg>
          Copied!
        `;
        button.classList.add('copied');
        
        setTimeout(() => {
          button.innerHTML = originalContent;
          button.classList.remove('copied');
        }, 2000);
      });
    });
  }

  showLoading() {
    const loadingDiv = document.createElement('div');
    loadingDiv.className = 'message ai-message loading-message';
    
    const avatar = document.createElement('div');
    avatar.className = 'avatar';
    avatar.innerHTML = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
      </svg>
    `;

    const loading = document.createElement('div');
    loading.className = 'loading';
    for (let i = 0; i < 3; i++) {
      loading.appendChild(document.createElement('span'));
    }

    loadingDiv.appendChild(avatar);
    loadingDiv.appendChild(loading);
    this.messagesContainer.appendChild(loadingDiv);
    this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
  }

  hideLoading() {
    const loadingMessage = this.messagesContainer.querySelector('.loading-message');
    if (loadingMessage) {
      loadingMessage.remove();
    }
  }
}