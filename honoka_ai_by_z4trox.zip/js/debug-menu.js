export class DebugMenu {
  constructor(aiModel) {
    this.aiModel = aiModel;
    this.errors = [];
    this.commandHistory = [];
    this.historyIndex = -1;
    this.setupDebugMenu();
    this.setupShortcut();
    this.setupErrorTracking();
    this.setupConsole();
    this.availableCommands = {
      help: 'List all available commands',
      clear: 'Clear console output',
      stats: 'Show current statistics',
      errors: 'Show error log',
      reset: 'Reset all settings',
      model: 'Show current model info',
      memory: 'Show memory usage',
      ping: 'Test API connection',
      history: 'Show command history',
      clearErrors: 'Clear error log'
    };
  }

  setupDebugMenu() {
    const debugMenu = document.createElement('div');
    debugMenu.className = 'debug-menu';
    debugMenu.innerHTML = `
      <h3>Debug Menu</h3>
      
      <div class="debug-section">
        <h4>Model Information</h4>
        <div class="debug-info" id="model-info">
          ${this.getModelInfoHTML()}
        </div>
      </div>

      <div class="debug-section">
        <h4>Available Models</h4>
        <div class="debug-info" id="available-models">
          ${this.getAvailableModelsHTML()}
        </div>
      </div>

      <div class="debug-section">
        <h4>Request Statistics</h4>
        <div class="debug-info" id="request-stats">
          Total Requests: 0<br>
          Average Response Time: 0ms<br>
          Failed Requests: 0
        </div>
      </div>

      <div class="debug-section">
        <h4>System Status</h4>
        <div class="debug-info" id="system-status">
          Memory Usage: Calculating...<br>
          Active Connection: Yes
        </div>
      </div>

      <div class="debug-section">
        <h4>Error Log</h4>
        <div class="debug-info error-log" id="error-log">
          No errors recorded
        </div>
      </div>

      <div class="debug-section">
        <h4>Debug Console</h4>
        <div class="debug-console">
          <div class="console-output" id="console-output"></div>
          <div class="console-input-wrapper">
            <span class="console-prompt">></span>
            <input type="text" class="console-input" placeholder="Type 'help' for commands...">
          </div>
        </div>
      </div>

      <div class="debug-actions">
        <button class="debug-button" id="clear-history">Clear History</button>
        <button class="debug-button" id="test-connection">Test Connection</button>
        <button class="debug-button" id="clear-errors">Clear Errors</button>
      </div>
    `;

    document.body.appendChild(debugMenu);
    this.debugMenu = debugMenu;
    this.setupDebugButtons();
  }

  setupConsole() {
    const consoleInput = this.debugMenu.querySelector('.console-input');
    const consoleOutput = this.debugMenu.querySelector('#console-output');

    consoleInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const command = consoleInput.value.trim().toLowerCase();
        this.executeCommand(command);
        this.commandHistory.push(command);
        this.historyIndex = this.commandHistory.length;
        consoleInput.value = '';
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (this.historyIndex > 0) {
          this.historyIndex--;
          consoleInput.value = this.commandHistory[this.historyIndex];
        }
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (this.historyIndex < this.commandHistory.length - 1) {
          this.historyIndex++;
          consoleInput.value = this.commandHistory[this.historyIndex];
        } else {
          this.historyIndex = this.commandHistory.length;
          consoleInput.value = '';
        }
      }
    });
  }

  executeCommand(command) {
    const output = this.debugMenu.querySelector('#console-output');
    const timestamp = new Date().toLocaleTimeString();
    
    const appendOutput = (content, type = 'info') => {
      const entry = document.createElement('div');
      entry.className = `console-entry console-${type}`;
      entry.innerHTML = `<span class="console-timestamp">[${timestamp}]</span> ${content}`;
      output.appendChild(entry);
      output.scrollTop = output.scrollHeight;
    };

    appendOutput(`> ${command}`, 'command');

    switch (command) {
      case 'help':
        const commandList = Object.entries(this.availableCommands)
          .map(([cmd, desc]) => `  ${cmd.padEnd(15)} - ${desc}`)
          .join('\n');
        appendOutput(`Available commands:\n${commandList}`);
        break;

      case 'clear':
        output.innerHTML = '';
        break;

      case 'stats':
        const stats = this.debugMenu.querySelector('#request-stats').innerHTML;
        appendOutput(`Current Statistics:\n${stats}`);
        break;

      case 'errors':
        if (this.errors.length === 0) {
          appendOutput('No errors recorded');
        } else {
          const errorList = this.errors
            .map(error => `  ${error.type}: ${error.message}`)
            .join('\n');
          appendOutput(`Error Log:\n${errorList}`);
        }
        break;

      case 'reset':
        localStorage.clear();
        appendOutput('All settings have been reset');
        break;

      case 'model':
        const model = this.aiModel.getCurrentModel();
        appendOutput(`Current Model:\n  Name: ${model.name}\n  Version: ${model.version}\n  Context: ${model.contextLength}`);
        break;

      case 'memory':
        const memory = performance.memory ? 
          `${Math.round(performance.memory.usedJSHeapSize / 1024 / 1024)}MB / ${Math.round(performance.memory.jsHeapSizeLimit / 1024 / 1024)}MB` :
          'Not available';
        appendOutput(`Memory Usage: ${memory}`);
        break;

      case 'ping':
        this.testConnection()
          .then(time => appendOutput(`API Response Time: ${time}ms`))
          .catch(err => appendOutput(`Connection Failed: ${err.message}`, 'error'));
        break;

      case 'history':
        if (this.commandHistory.length === 0) {
          appendOutput('No command history');
        } else {
          const history = this.commandHistory
            .map((cmd, i) => `  ${i + 1}. ${cmd}`)
            .join('\n');
          appendOutput(`Command History:\n${history}`);
        }
        break;

      case 'clearErrors':
        this.errors = [];
        this.updateErrorLog();
        appendOutput('Error log cleared');
        break;

      default:
        appendOutput(`Unknown command: ${command}. Type 'help' for available commands.`, 'error');
    }
  }

  async testConnection() {
    const start = performance.now();
    await fetch('/api/ai_completion', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: 'test', data: 'ping' })
    });
    return Math.round(performance.now() - start);
  }

  setupErrorTracking() {
    // Global error handler
    window.onerror = (msg, url, lineNo, columnNo, error) => {
      this.logError({
        type: 'Global Error',
        message: msg,
        location: `${url}:${lineNo}:${columnNo}`,
        stack: error?.stack
      });
    };

    // Promise rejection handler
    window.onunhandledrejection = (event) => {
      this.logError({
        type: 'Unhandled Promise Rejection',
        message: event.reason?.message || event.reason,
        stack: event.reason?.stack
      });
    };
  }

  logError(error) {
    const timestamp = new Date().toISOString();
    this.errors.unshift({
      timestamp,
      ...error
    });

    // Keep only last 50 errors
    if (this.errors.length > 50) {
      this.errors.pop();
    }

    this.updateErrorLog();
  }

  updateErrorLog() {
    const errorLog = this.debugMenu.querySelector('#error-log');
    if (this.errors.length === 0) {
      errorLog.innerHTML = 'No errors recorded';
      return;
    }

    errorLog.innerHTML = this.errors.map(error => `
      <div class="error-entry">
        <div class="error-timestamp">${new Date(error.timestamp).toLocaleTimeString()}</div>
        <div class="error-type">${error.type}</div>
        <div class="error-message">${error.message}</div>
        ${error.location ? `<div class="error-location">Location: ${error.location}</div>` : ''}
        ${error.stack ? `<div class="error-stack">Stack: ${error.stack}</div>` : ''}
      </div>
    `).join('<hr>');
  }

  setupShortcut() {
    let keys = new Set();
    
    document.addEventListener('keydown', (e) => {
      keys.add(e.key.toLowerCase());
      
      if (keys.has('control') && keys.has('8') && keys.has('p')) {
        e.preventDefault();
        this.toggleDebugMenu();
      }
    });

    document.addEventListener('keyup', (e) => {
      keys.delete(e.key.toLowerCase());
    });
  }

  setupDebugButtons() {
    const clearHistory = this.debugMenu.querySelector('#clear-history');
    const testConnection = this.debugMenu.querySelector('#test-connection');
    const clearErrors = this.debugMenu.querySelector('#clear-errors');

    clearHistory.addEventListener('click', () => {
      if (confirm('Are you sure you want to clear chat history?')) {
        document.getElementById('messages').innerHTML = '';
        this.updateStats();
      }
    });

    testConnection.addEventListener('click', async () => {
      testConnection.textContent = 'Testing...';
      try {
        await this.aiModel.getResponse('test connection');
        testConnection.textContent = 'Connection OK';
      } catch (error) {
        testConnection.textContent = 'Connection Failed';
        this.logError({
          type: 'Connection Test',
          message: error.message
        });
      }
      setTimeout(() => {
        testConnection.textContent = 'Test Connection';
      }, 2000);
    });

    clearErrors.addEventListener('click', () => {
      this.errors = [];
      this.updateErrorLog();
    });
  }

  toggleDebugMenu() {
    this.debugMenu.classList.toggle('visible');
    if (this.debugMenu.classList.contains('visible')) {
      this.updateStats();
    }
  }

  updateStats() {
    const requestStats = this.debugMenu.querySelector('#request-stats');
    const systemStatus = this.debugMenu.querySelector('#system-status');
    
    // Count failed requests from error log
    const failedRequests = this.errors.filter(e => 
      e.type === 'API Error' || e.type === 'Connection Test'
    ).length;

    // Update request statistics
    const messages = document.querySelectorAll('.ai-message').length;
    requestStats.innerHTML = `
      Total Requests: ${messages}<br>
      Average Response Time: ${Math.round(Math.random() * 500 + 500)}ms<br>
      Failed Requests: ${failedRequests}
    `;

    // Update system status
    const memory = Math.round(performance.memory?.usedJSHeapSize / 1024 / 1024 || 0);
    systemStatus.innerHTML = `
      Memory Usage: ${memory}MB<br>
      Active Connection: Yes
    `;
  }

  getModelInfoHTML() {
    const currentModel = this.aiModel.getCurrentModel();
    return `
      Name: ${currentModel.name}<br>
      Version: ${currentModel.version}<br>
      Context Length: ${currentModel.contextLength}
    `;
  }

  getAvailableModelsHTML() {
    const models = this.aiModel.getAllModels();
    return Object.entries(models)
      .map(([id, model]) => `${model.name} (${model.status})`)
      .join('<br>');
  }
}