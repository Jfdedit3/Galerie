export function setupMobileNavigation() {
  const hamburger = document.querySelector('.hamburger-menu');
  const sidebar = document.querySelector('.sidebar');
  const backdrop = document.querySelector('.backdrop');
  const navItems = document.querySelectorAll('.nav-item');
  const newChatMobile = document.querySelector('.new-chat-mobile');
  const newChatSidebar = document.querySelector('.new-chat');

  function toggleMenu() {
    hamburger.classList.toggle('active');
    sidebar.classList.toggle('active');
    backdrop.classList.toggle('active');
    document.body.style.overflow = sidebar.classList.contains('active') ? 'hidden' : '';
  }

  hamburger.addEventListener('click', toggleMenu);
  backdrop.addEventListener('click', toggleMenu);

  // Add event listener to mobile new chat button
  newChatMobile?.addEventListener('click', () => {
    // Reset chat or start a new conversation
    document.getElementById('messages').innerHTML = '';
    // Add initial welcome message
    const initialMessage = document.createElement('div');
    initialMessage.className = 'message ai-message';
    initialMessage.innerHTML = `
      <div class="avatar">
        <img src="https://files.catbox.moe/evfh55.jpg" alt="Honoka AI" class="avatar-img">
      </div>
      <div class="message-content">
        <div class="message-header">
          <span class="ai-name">Honoka</span>
          <span class="timestamp">Now</span>
        </div>
        <div class="content">
          Hello! I'm Honoka, your AI assistant. How can I help you today?
        </div>
      </div>
    `;
    document.getElementById('messages').appendChild(initialMessage);
  });

  // Sync sidebar and mobile new chat buttons
  newChatSidebar?.addEventListener('click', () => {
    newChatMobile?.click();
    if (window.innerWidth <= 1024) {
      toggleMenu();
    }
  });

  // Close menu when navigation item is clicked
  navItems.forEach(item => {
    item.addEventListener('click', () => {
      if (window.innerWidth <= 1024) {
        toggleMenu();
      }
    });
  });

  // Responsive resize handling
  let resizeTimer;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      if (window.innerWidth > 1024) {
        hamburger.classList.remove('active');
        sidebar.classList.remove('active');
        backdrop.classList.remove('active');
        document.body.style.overflow = '';
      }
    }, 250);
  });
}